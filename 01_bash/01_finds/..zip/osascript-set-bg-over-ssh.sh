 §sudo osascript -e tell application "Finder" \;
    set desktop picture to POSIX file "/Volumes/FINALS_afp/INCOMING/MEDIAMANAGER/suite11_01.png" \; end tell ;