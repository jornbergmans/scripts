#/bin/bash

for f in $(find . -type f -ipath '*RENDER*CLEAN*' \( -and -iname ".ds_*" -or -iname "._*" \))
	do rm -fv '$f' \;
	
done 

find . -type d -empty -ipath '*RENDER*CLEAN*'