#!/bin/bash 

opschonen()	
	{
	
find . -type f 	\( -and -ipath "*02_Footage*" -or -ipath "*03_Artwork*" -or -ipath "*04_Restored-Project*" -or -ipath "*06_Grading*" \)

find . -type f 	\( -ipath "*05_Audio*" -and \! -ipath "*05_Audio/*Finals/*" \)
find . -type f 	\( -ipath "*01_Projects*" -and \! -iname "*.prproj" -and \! -iname "*.aep" \) \

find . -type f 	\( -ipath "*07_Renders*" -and \! -ipath "*04_*" -or \! -ipath "*05_*" \) \

	}

opschonen;