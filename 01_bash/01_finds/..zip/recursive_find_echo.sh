#/bin/bash/
for f in $(find . -name "*.mov"); do
    echo "$f"
    find . -name "*.mov" > ./movlist.txt
    
done

for name in $(find . -name "*mov.mp4"); do
		mv "${name}" ${name/mov.mp4/mp4}	 	

	find . -name "*.mp4" > ./mp4list.txt
		    
done