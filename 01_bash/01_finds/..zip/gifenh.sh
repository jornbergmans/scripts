#/bin/sh 

		for f in $(find . -name "*.mov"); do
			ffmpeg -y -i $f -vf fps=10,scale=-1:1080:flags=lanczos,palettegen ./$f-palette.png

			
			ffmpeg -y -i $f -i ./$f-palette.png -filter_complex \
		"fps=10,scale=-1:720:flags=lanczos[x];[x][1:v]paletteuse" -f gif $f.gif

	done

		for name in $(find . -name "*mov.gif"); do
		mv "${name}" ${name/mov.gif/gif}

	done
