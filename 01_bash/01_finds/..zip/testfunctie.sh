dier()

	{ 
find . -type f 	\( -ipath "*05_Audio*" -and \! -ipath "*05_Audio/*Finals/*" \)
	}
	
dier[5];