#!/bin/bash


findArray=(
)

MijnURLS=${#findArray[@]}
MijnStoel="ietsAnders"
#echo $MijnURLS   	





for ((i=0 ; i <= MijnURLS ; i++)); 
do

	
	
	findArray[i] = 
	echo ${findArray[i]}
done



#				find . \(-and \! -ipath "*00_Docs*" -and \! -ipath "*01_Projects*" -and \! -ipath "*_Finals*" \); do
			
#				rm -Rfv 
#				rmdir 