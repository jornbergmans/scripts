#!/bin/bash/

cp -Rv /Applications/Adobe After Effects CC 2015/Plug-ins/VideoCopilot /Applications/Adobe After Effects CC 2015.3/Plug-ins/VideoCopilot

cp -Rfv /Applications/Adobe After Effects CC 2015/Plug-ins/Additional Plugins /Applications/Adobe After Effects CC 2015.3/Plug-ins/Additional Plugins