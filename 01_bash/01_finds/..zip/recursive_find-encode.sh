#/bin/bash/

for f in $(find . -name "*.mov"); do
    echo "$f"
       	ffmpeg -y -i "$f" -c:v libx264 -b:v 2500k -c:a libfdk_aac -b:a 96k -f mp4 $f.mp4
    find .-name "*.mov" > ./movlist.txt
    
done

for name in $(find . -name "*mov.mp4"); do
		mv "${name}" ${name/mov.mp4/mp4}	 	

	find . -name "*.mp4" > ./mp4list.txt
		    
done