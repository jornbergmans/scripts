#/bin/bash

	for f in $(find . -d 1 -iname "*.mov"); do
		
		ffmpeg -i "$f" -sws_flags lanczos -r 25 -vsync passthrough -vcodec copy -acodec copy -mbd rd -f mov ./ffmpeg_conform/$f ;
#		 -pix_fmt yuva4444p10le
		
	done
	
	
#	for %%a in (“*.mov”) do ffmpeg -i “%%a” -s 1280×720 -sws_flags lanczos -r 23.98 -vsync passthrough -vcodec dnxhd -b 110M -mbd rd -acodec copy “%%~na.DNxHD.mov”
	
	