#/bin/bash/

	for f in $(find . -type f -ipath "*_renders/*clean*" -iname ".DS_Store"); do
#	for f in $(find . -type f -ipath "*_renders/*final*" -iname ".DS_Store"); do

		rm -fv "$f"
	
done 

	
	for d in $(find . -type d -empty -ipath "*_renders/*clean*"); do
# 	for d in $(find . -type d -empty -ipath "*_renders/*final*"); do
		echo "$d"
	
done