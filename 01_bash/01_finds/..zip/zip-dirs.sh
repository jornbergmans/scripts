#/bin/bash

IFS=$'\n'

	for zips in $(find . -type d); do
	
	echo "$zips"
	zip -rv0 "$zips".zip $zips
	
		
done