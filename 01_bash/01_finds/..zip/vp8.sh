#/bin/bash/

IFS=$'\n'

for i in $(find . -name "*.mov"); do
    echo "$i"

		ffmpeg -y -i "$i" -c:v libvpx -pass 1 -b:v 3500k -threads 1 -speed 4 \
	  -tile-columns 0 -frame-parallel 0 \
		-keyint_min 1 -an -f webm /dev/null

		ffmpeg -y -i "$i" -c:v libvpx -pass 2 -b:v 3500k -threads 1 -speed 0 \
		-qmin 10 -qmax 42 \
	  -tile-columns 0 -frame-parallel 0 -auto-alt-ref 1 -lag-in-frames 0 -arnr-type backward \
		-keyint_min 1 -an -f webm $i.webm
		
done

for name in $(find . -name "*mov.webm"); do
	mv "${name}" ${name/mov.webm/webm}
	echo "$name"
		
done


#	  -force_key_frames 00:00:00.00,00:00:04.24,00:00:09.24,00:00:14.24,00:00:19.24,00:00:24.24,00:00:29.24,00:00:34.24,00:00:39.24,00:00:44.24,00:00:49.24,00:00:54.24,00:00:59.19 \