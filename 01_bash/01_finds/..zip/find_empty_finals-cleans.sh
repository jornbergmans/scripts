#/bin/bash

IFS=$'\n'

#find /Volumes/ALPHA/02_ARCHIVE/ALPHA\ TO\ ARCHIVE/ 		-type f 	-ipath "*final*" -and \! -ipath "*audio*"	\(	-and -iname "._*" 	-or -iname ".DS*" 	-or -iname "*afpdel*" \) -exec rm -fv {} 	 \;
#find /Volumes/BETA/02_ARCHIVE/BETA\ TO\ ARCHIVE/ 		-type f 	-ipath "*final*" -and \! -ipath "*audio*"	\(	-and -iname "._*" 	-or -iname ".DS*" 	-or -iname "*afpdel*" \) -exec rm -fv {} 	 \;
#find /Volumes/DELTA/02_ARCHIVE/DELTA\ TO\ ARCHIVE/ 		-type f 	-ipath "*final*" -and \! -ipath "*audio*"	\(	-and -iname "._*" 	-or -iname ".DS*" 	-or -iname "*afpdel*" \) -exec rm -fv {} 	 \;

echo "ALPHA"
echo "- finals"
find /Volumes/ALPHA/02_ARCHIVE/ALPHA\ TO\ ARCHIVE/ 		-type d 	\( -and -iname "*final*" 	-and \! -ipath "*audio*" \) -empty
echo "- cleans"
find /Volumes/ALPHA/02_ARCHIVE/ALPHA\ TO\ ARCHIVE/ 		-type d 	\( -and -iname "*clean*" 	-and \! -ipath "*audio*" \) -empty

echo "BETA"
echo "- finals"
#find /Volumes/BETA/02_ARCHIVE/BETA\ TO\ ARCHIVE/		-type d 	\( -and -iname "*final*" 	-and \! -ipath "*audio*" \) -empty
echo "- cleans"
#find /Volumes/BETA/02_ARCHIVE/BETA\ TO\ ARCHIVE/		-type d 	\( -and -iname "*clean*" 	-and \! -ipath "*audio*" \) -empty

echo "DELTA"
echo "- finals"
#find /Volumes/DELTA/02_ARCHIVE/DELTA\ TO\ ARCHIVE/ 		-type d 	\( -and -iname "*final*" 	-and \! -ipath "*audio*" \) -empty
echo "- cleans"
#find /Volumes/DELTA/02_ARCHIVE/DELTA\ TO\ ARCHIVE/ 		-type d 	\( -and -iname "*clean*" 	-and \! -ipath "*audio*" \) -empty